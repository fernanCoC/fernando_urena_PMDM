package controller

class EntradaPrincipal {
}
    fun main() {
        val central = Centralita()
        central.hacerLlamadas(LlamadaNacional("Leganes","Girona",18,1))
        central.hacerLlamadas(LlamadaNacional("Leganes","Girona",38,2))
        central.hacerLlamadas(LlamadaNacional("Leganes","Girona",57,3))

        central.mostrarLlamadas();
        central.mostrarCostesLlamadas()
    }

