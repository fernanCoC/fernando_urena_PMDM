package controller

class LlamadaLocal(nOrigen:String,nDestino:String,duracion:Int): Llamadas(nOrigen,nDestino,duracion ) {
    init {
        coste=calcularCoste()
    }
    override fun calcularCoste(): Double {
       return 0.0
    }
}