package controller

import java.lang.reflect.Array.get

 class LlamadaNacional(nOrigen:String, nDestino:String,
                               duracion:Int,
                               val franja:Int):Llamadas(nOrigen, nDestino, duracion) {

    override fun calcularCoste(): Double {
        return when(franja){
            1 -> duracion*0.20
            2 -> duracion*0.25
            3 -> duracion*0.3
            else -> 0.0
        }

    }
}