package controller

abstract class Llamadas( val nOrigen:String,
                         val nDestino:String,
                         val duracion:Int)
{
   var coste :Double =0.0
       protected set
    abstract fun calcularCoste():Double



}